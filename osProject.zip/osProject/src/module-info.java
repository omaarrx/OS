/**
 * 
 */
/**
 * @author Karas
 *
 */
module osProject {
}